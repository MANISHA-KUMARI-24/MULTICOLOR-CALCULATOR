# calculator
A full responsive multicolor CALCULATOR based on HTML, CSS &amp; JavaScript. 

 https://yashuum.github.io/calculator/
