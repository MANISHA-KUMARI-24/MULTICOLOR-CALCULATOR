Thanks for visitng my GIT Profile. 

This is a simple caluclator (multicolor as well as responsive) project based on HTML,CSS & JS. 
You can perform any mathematical calulations with this calculator. But rember that this is not a scientific calulator. 

If you want this  full project with some modifications please mail back to me at singhyashwant559@gmail.com or simply visit my website - www.cwayofficials.tk 